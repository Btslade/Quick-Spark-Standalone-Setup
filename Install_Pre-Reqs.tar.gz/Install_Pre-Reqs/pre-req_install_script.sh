#!/bin/bash


### Ensure that a tmp directory is created for spark to do work in

while getopts "pbvh" opt; do
    case $opt in
        p) p=true;;
        b) b=true;;
        v) v=true;;
        h) echo "-p: install pre-requisites, NEED TO BE RUN WITH SUDO"
            echo "-b: pip install on base machine instead of a virtual enviornment"
            echo "-v: pip install on a virtual enviornment called env "
            exit;;
    esac
done

if [[ $p == true ]]; then
    echo Ensure you run this with sudo
    sleep 3
    sudo yum install java -y
    sudo yum install python3 -y
    sudo su - root << EOF 
    pip3 install --upgrade pip 
EOF
exit
fi

if [[ $b == true ]]; then
    echo Before continuing ensure you have the most up to date pip 
    echo Run: pip install --upgrade pip
    sleep 3
    pip3 install pandas
    pip3 install pyspark
    pip3 install findspark
    pip3 install numpy
    pip3 install petastorm
    pip3 install jupyter 
    pip3 install tensorflow
    pip3 install keras
    pip3 install matplotlib 
    pip3 install seaborn
    exit
fi

if [[ $v == true ]]; then
    echo Before continuing ensure you have the most up to date pip 
    echo Run: pip install -- upgrade
    sleep 3
    python3.6 -m venv env
    source env/bin/activate
    pip3 install pandas
    pip3 install pyspark
    pip3 install findspark
    pip3 install numpy 
    pip3 install petastorm
    pip3 install jupyter 
    pip3 install tensorflow
    pip3 install keras
    pip3 install matplotlib
    pip3 install seaborn
    exit
fi

echo "-p: install pre-requisites, NEED TO BE RUN WITH SUDO"
echo "-b: pip install on base machine instead of a virtual enviornment"
echo "-v: pip install on a virtual enviornment called env "
exit
