
while getopts ":p:n:s:m:f:v" opt; do
    case $opt in
        p) prefix="$OPTARG"; p=true;;
        n) nodeNum="$OPTARG"; n=true;;
        s) sparkStandAlone="$OPTARG"; s=true;;
        m) masterAddress="$OPTARG"; m=true;;
        v) echo "Verbose Debug Mode Activated"; v=true;;
    esac
done





ssh $prefix""$nodeNum << EOF
echo Starting worker on node $prefix""$nodeNum 
$sparkStandAlone/sbin/start-slave.sh $masterAddress
EOF
