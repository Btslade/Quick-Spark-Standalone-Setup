#NOTE RUN THIS SCRIPT ON THE NODE YOU WANT TO BE THE MASTER


# This is how multiple nodes are defined  ph[01-02,04-06]


#############
# Arguments #
#############
c=false
j=false
nodeCount=1
nodeNames="ph"
SPARK_STANDALONE="$HOME/spark-3.0.1-bin-hadoop3.2"
while getopts ":c:n:j:s:vh" opt; do
    case $opt in
        c) nodeCount="$OPTARG"; c=true;;
        m) MASTER_ADDRESS="$OPTARG"; m=true;;
        j) JOB_ID="$OPTARG"; j=true;;
        s) SPARK_STANDALONE="$OPTARG"; s=true;;
        v) echo "Verbose Debug Mode Activated"; v=true;;
        h) echo "-c: How many nodes you have allocated";
            echo "-n: Node Name Prefix";
            echo "-j: JobID";
            echo "-s: Spark Home";
            echo "-v: enable verbose debug mode";
            exit;;
    esac
done


##############
# Begin Code #
##############

if [ "$c" == false ] || [ "$j" == false ]; then
    echo "Make sure you provide the node count (-c <num of nodes allocated>) and the jobid (-j <jobid>)"
    exit
fi



######################################
# Check All Arguments (VERBOSE ONLY) #
######################################



if [ "$v" == true ]; then
    echo "Number of nodes for job is: $nodeCount"
    echo "JobId is: $JOB_ID"
    echo "Spark stand alone home is: $SPARK_STANDALONE"
    echo "Starting Master and Slave on Node:"
fi

####################
# Shut Down Master #
####################
$SPARK_STANDALONE/sbin/stop-master.sh


#############################
# If only one node end here #
#############################
if [ "$nodeCount" -eq 1 ]; then
    $SPARK_STANDALONE/sbin/stop-slave.sh 
    exit
fi 

########################################
# Get Required information from squeue #
########################################

key=$(squeue | sed -n  /$JOB_ID/p | awk 'NF>1{print $NF}')
if [[ $v == true ]]; then
    echo this is the key: $key
fi



cluster_prefix=$(echo $key | cut -f1 -d[)

if [[ $v == true ]]; then
    echo this is the cluster prefix: $cluster_prefix
fi

nodes1=$(echo $key | cut -f2 -d[ | sed 's/]//g')

if [[ $v == true ]]; then
    echo this is nodes $nodes1
fi


######################
# Shut Down Workers  #
######################

for i in $(echo $nodes1 | sed "s/,/ /g")
do
    if [[ $i == *"-"* ]]; 
    then
        num1=$(echo $i | cut -f1 -d-)
        num2=$(echo $i | cut -f2 -d-)
        for num in $(seq -w $num1 $num2);
        do 
            if [[ $v == true ]]; then
                echo sshing into node ph$num
            fi
            ./stop_slave_script.sh -p $cluster_prefix -n $num -s $SPARK_STANDALONE 
       done 
    else
        ./stop_slave_script1.sh -f "ph"$i -s $SPARK_STANDALONE 
    fi
done
