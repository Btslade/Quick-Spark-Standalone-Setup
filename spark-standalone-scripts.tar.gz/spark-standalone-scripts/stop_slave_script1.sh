while getopts ":f:s:m:f:v" opt; do
    case $opt in
        f) fullName="$OPTARG"; f= true;;
        s) sparkStandAlone="$OPTARG"; s=true;;
        v) echo "Verbose Debug Mode Activated"; v=true;;
    esac
done





ssh $fullName << EOF
echo Stopping worker on node: $fullName
$sparkStandAlone/sbin/stop-slave.sh
EOF
