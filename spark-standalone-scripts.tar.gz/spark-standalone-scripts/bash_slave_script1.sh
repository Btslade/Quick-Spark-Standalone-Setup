#!/bin/bash

while getopts ":f:s:m:f:v" opt; do
    case $opt in
        f) fullName="$OPTARG"; f= true;;
        s) sparkStandAlone="$OPTARG"; s=true;;
        m) masterAddress="$OPTARG"; m=true;;
        v) echo "Verbose Debug Mode Activated"; v=true;;
    esac
done





ssh $fullName << EOF
/bin/bash $sparkStandAlone/sbin/start-slave.sh $masterAddress
EOF
